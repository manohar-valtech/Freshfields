require({cache:{
'url:epi/patch/dijit/templates/MenuItem.html':"<tr class=\"dijitReset dijitMenuItem\" data-dojo-attach-point=\"focusNode\" role=\"menuitem\" tabIndex=\"-1\">\r\n    <td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n        <span class=\"dijitInline dijitIcon dijitMenuItemIcon\" data-dojo-attach-point=\"iconNode\"/>\r\n    </td>\r\n    <td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" data-dojo-attach-point=\"containerNode\"></td>\r\n    <td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" data-dojo-attach-point=\"accelKeyNode\"></td>\r\n    <td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">\r\n        <div data-dojo-attach-point=\"arrowWrapper\" style=\"visibility: hidden\">\r\n            <span class=\"dijitMenuExpand\"/>\r\n            <span class=\"dijitMenuExpandA11y\">+</span>\r\n        </div>\r\n    </td>\r\n</tr>\r\n",
'url:epi/patch/dijit/templates/CheckedMenuItem.html':"<tr class=\"dijitReset dijitMenuItem\" data-dojo-attach-point=\"focusNode\" role=\"menuitemcheckbox\" tabIndex=\"-1\" aria-checked=\"${checked}\">\r\n    <td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n        <span class=\"dijitInline dijitIcon dijitMenuItemIcon\" data-dojo-attach-point=\"iconNode\" />\r\n    </td>\r\n    <td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" data-dojo-attach-point=\"containerNode,labelNode\"></td>\r\n    <td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" data-dojo-attach-point=\"accelKeyNode\"></td>\r\n    <td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">&#160;</td>\r\n</tr>\r\n"}});
define("epi/patch/dijit/MenuItem", [
    "dijit/MenuItem",
    "dijit/CheckedMenuItem",
    "dojo/text!./templates/MenuItem.html",
    "dojo/text!./templates/CheckedMenuItem.html"
], function(MenuItem, CheckedMenuItem, menuItemTemplate, checkedMenuItemTemplate){
    // Patch to change iconNode from img to span, so that Axiom icons can be used.
    Object.assign(MenuItem.prototype, {
        templateString: menuItemTemplate
    });

    Object.assign(CheckedMenuItem.prototype, {
        templateString: checkedMenuItemTemplate
    });
});
