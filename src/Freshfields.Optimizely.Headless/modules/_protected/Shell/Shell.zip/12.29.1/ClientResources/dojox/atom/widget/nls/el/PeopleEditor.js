//>>built
define("dojox/atom/widget/nls/el/PeopleEditor",({add:"Προσθήκη",addAuthor:"Προσθήκη συντάκτη",addContributor:"Προσθήκη συνεισφέροντα"}));