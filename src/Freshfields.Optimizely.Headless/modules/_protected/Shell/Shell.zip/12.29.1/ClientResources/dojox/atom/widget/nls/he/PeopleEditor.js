//>>built
define("dojox/atom/widget/nls/he/PeopleEditor",({add:"הוספה",addAuthor:"הוספת מחבר",addContributor:"הוספת תורם"}));