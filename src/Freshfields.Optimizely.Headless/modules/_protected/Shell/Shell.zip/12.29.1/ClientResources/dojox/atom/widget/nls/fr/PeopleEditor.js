//>>built
define("dojox/atom/widget/nls/fr/PeopleEditor",({add:"Ajouter",addAuthor:"Ajouter un auteur",addContributor:"Ajouter un collaborateur"}));